<?php
class SomeClass
{
    public function doSomething($a, $b)
    {
        return null;
    }

    public function doSomethingElse($c)
    {
        return null;
    }
}
